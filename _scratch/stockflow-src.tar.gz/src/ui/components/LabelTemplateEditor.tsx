import { useEffect, useId, useRef, useState, type FormEvent, type KeyboardEvent } from 'react'
import type { Product } from '../../domain/types'
import {
  DEFAULT_LABEL_TEMPLATE,
  DEFAULT_POLONO_LABEL_TEMPLATE,
  FONT_FAMILY_FIELD,
  FONT_SIZE_FIELD,
  MAX_CUSTOM_FONT_DOTS,
  MAX_FONT,
  MAX_LOGO_DOTS,
  MIN_CUSTOM_FONT_DOTS,
  MIN_FONT,
  MIN_LOGO_DOTS,
  POLONO_FONT_CHOICES,
  PRINTER_LABELS,
  approxTextWidthDots,
  estimateBarcodeWidthDots,
  sanitiseLabelTemplate,
  textFamilyFor,
  textHeightDots,
  textSizeDotsFor,
  truncateToFitDots,
  type ElementPosition,
  type LabelTemplate,
  type PolonoPrintRotation,
  type PrinterKind,
  type TextElementKey,
} from '../../printing/labelTemplate'
import { printProductLabel } from '../../printing/printLabel'
import type { SettingsApi } from '../useSettings'

export interface LabelTemplateEditorProps {
  settings: SettingsApi
}

/** A stand-in product used only for the "print test label" button and the live preview. */
const SAMPLE_PRODUCT: Product = {
  id: 'sample',
  barcode: '',
  sku: 'SKU-0001',
  name: 'Sample Product Name',
  category: '',
  location: '',
  variation: 'Blue / Large',
  quantity: 1,
  reorderLevel: 0,
  cost: 0,
  price: 0,
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
}

const FIELD_LIMITS = {
  widthDots: { min: 100, max: 4000 },
  heightDots: { min: 100, max: 4000 },
  dpi: { min: 100, max: 600 },
  barcodeHeight: { min: 10, max: 1000 },
  barcodeModuleWidth: { min: 1, max: 10 },
  logoWidthDots: { min: MIN_LOGO_DOTS, max: MAX_LOGO_DOTS },
  logoHeightDots: { min: MIN_LOGO_DOTS, max: MAX_LOGO_DOTS },
  darkness: { min: 0, max: 30 },
  printSpeedIps: { min: 2, max: 12 },
} as const

// Was 420 — too small on a real screen to drag/position things precisely,
// especially the Polono's short 406x203-dot label, which rendered under
// 4in wide on most monitors. Bumped to 760 so the editor box itself is
// roughly twice the size to work in. This only changes how big the editing
// canvas renders on screen (`scale` below) — it has no effect on the
// physical label size or what gets sent to the printer, which stay exactly
// what `widthDots`/`heightDots` say regardless of this constant.
const PREVIEW_MAX_WIDTH = 760

/** Every physical field is stored in dots (what CPCL speaks) but can be
 * viewed and edited in inches or millimetres — converted using the
 * template's own DPI, since dots only mean a physical size at a given
 * resolution. */
type Unit = 'dots' | 'in' | 'mm'

const UNIT_OPTIONS: { value: Unit; label: string }[] = [
  { value: 'dots', label: 'Dots' },
  { value: 'in', label: 'Inches' },
  { value: 'mm', label: 'Millimetres' },
]

const UNIT_SUFFIX: Record<Unit, string> = { dots: 'dots', in: 'in', mm: 'mm' }
const UNIT_STEP: Record<Unit, number> = { dots: 1, in: 0.01, mm: 0.5 }
const MM_PER_INCH = 25.4

const dotsToUnit = (dots: number, unit: Unit, dpi: number): number => {
  if (unit === 'dots') return dots
  const inches = dots / dpi
  return unit === 'in' ? inches : inches * MM_PER_INCH
}

const unitToDots = (value: number, unit: Unit, dpi: number): number => {
  if (unit === 'dots') return value
  const inches = unit === 'in' ? value : value / MM_PER_INCH
  return inches * dpi
}

/** Rounds for display only — full precision is kept in the stored dots value. */
const roundForUnit = (value: number, unit: Unit): number => {
  const decimals = unit === 'dots' ? 0 : unit === 'in' ? 3 : 1
  const factor = 10 ** decimals
  return Math.round(value * factor) / factor
}

const clampNum = (value: number, min: number, max: number): number => Math.min(max, Math.max(min, value))

const commitOnEnter = (event: KeyboardEvent<HTMLInputElement>) => {
  if (event.key === 'Enter') event.currentTarget.blur()
}

interface DimensionFieldProps {
  id: string
  label: string
  dotsValue: number
  dpi: number
  unit: Unit
  min: number
  max: number
  isDimension: boolean
  hint?: string
  onCommit: (dots: number) => void
}

/**
 * A numeric field for label size, DPI and barcode height.
 *
 * Two things make the native `<input type="number">` painful for millimetre
 * values: its spin arrows are tiny and step by a fixed amount, so nudging a
 * width from 100mm to 50mm means dozens of taps that feel like "just
 * scrolling up and down"; and fully re-deriving + clamping the display value
 * on every keystroke fights you mid-edit — clearing the field to type a new
 * number snaps straight back to the min/max before you've finished typing.
 *
 * This keeps its own text buffer while the field has typing in flight (never
 * rewritten out from under the user), only parses/clamps/converts on blur or
 * Enter, and swaps the native spinner for two large +/- buttons that step by
 * one whole display unit per press.
 */
function DimensionField({
  id,
  label,
  dotsValue,
  dpi,
  unit,
  min,
  max,
  isDimension,
  hint,
  onCommit,
}: DimensionFieldProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const displayValue = isDimension ? roundForUnit(dotsToUnit(dotsValue, unit, dpi), unit) : dotsValue
  const displayMin = isDimension ? dotsToUnit(min, unit, dpi) : min
  const displayMax = isDimension ? dotsToUnit(max, unit, dpi) : max
  const step = isDimension ? UNIT_STEP[unit] : 1

  const [text, setText] = useState(() => String(displayValue))

  // Resync from the outside — a unit switch, "reset to defaults", or the DPI
  // field changing what a dot is worth — but only while this field isn't the
  // one being typed into, so we never overwrite an in-progress edit.
  useEffect(() => {
    if (document.activeElement !== inputRef.current) {
      setText(String(displayValue))
    }
  }, [displayValue])

  const commit = (nextDisplay: number) => {
    const clamped = clampNum(nextDisplay, displayMin, displayMax)
    const dots = isDimension ? Math.round(unitToDots(clamped, unit, dpi)) : Math.round(clamped)
    onCommit(dots)
    setText(String(isDimension ? roundForUnit(clamped, unit) : Math.round(clamped)))
  }

  const commitTypedText = () => {
    const parsed = Number(text)
    if (text.trim() === '' || Number.isNaN(parsed)) {
      setText(String(displayValue)) // nothing usable typed yet — revert rather than clamp mid-edit
      return
    }
    commit(parsed)
  }

  const nudge = (direction: 1 | -1) => {
    const base = Number(text)
    const current = Number.isNaN(base) ? displayValue : base
    commit(current + direction * step)
  }

  return (
    <div className="field">
      <label htmlFor={id}>
        {label}
        {isDimension ? ` (${UNIT_SUFFIX[unit]})` : ''}
      </label>
      <div className="number-stepper">
        <button type="button" className="button" aria-label={`Decrease ${label}`} onClick={() => nudge(-1)}>
          −
        </button>
        <input
          ref={inputRef}
          id={id}
          type="text"
          inputMode="decimal"
          value={text}
          onChange={(event) => setText(event.target.value)}
          onBlur={commitTypedText}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              commitTypedText()
              inputRef.current?.blur()
            }
          }}
        />
        <button type="button" className="button" aria-label={`Increase ${label}`} onClick={() => nudge(1)}>
          +
        </button>
      </div>
      {hint && <span className="hint">{hint}</span>}
    </div>
  )
}

type ElementKey = 'logo' | 'name' | 'variation' | 'barcode' | 'sku'

const ELEMENT_LABEL: Record<ElementKey, string> = {
  logo: 'Logo',
  name: 'Name',
  variation: 'Variation',
  barcode: 'Barcode',
  sku: 'SKU text',
}

/** The three text elements resize by changing their CPCL font index on the
 * Zebra — the printer's built-in bitmap fonts only come in 8 fixed sizes
 * (0–7), so dragging a resize handle steps through those 8 sizes rather
 * than resizing continuously. The Polono instead resizes these three
 * continuously, in real dots, via `nameFontSizeDots` etc. — see
 * `textSizeDotsFor` in `labelTemplate.ts`. The barcode and logo are the two
 * elements with independent, freely variable dimensions on both printers:
 * the barcode's bar height and — via CPCL's module-width parameter — its
 * overall printed width; the logo's box width and height, scaled to fit
 * within (see `rasterizeLogo`). */
const FONT_FIELD: Record<TextElementKey, 'nameFont' | 'variationFont' | 'skuFont'> = {
  name: 'nameFont',
  variation: 'variationFont',
  sku: 'skuFont',
}

type ResizableKey = TextElementKey | 'barcode' | 'logo'

/** Every resizable element gets a handle at each of its four corners, not
 * just the bottom-right one — if the element has been dragged off the edge
 * of the label, the corner still on-screen is the only one you can grab. */
type Corner = 'nw' | 'ne' | 'sw' | 'se'
const CORNERS: Corner[] = ['nw', 'ne', 'sw', 'se']
/** Which direction along each axis counts as "growing" for a given corner —
 * dragging any corner outward (away from the box's centre) grows it, and
 * dragging it inward shrinks it, regardless of which corner is grabbed. */
const CORNER_SIGN: Record<Corner, { x: 1 | -1; y: 1 | -1 }> = {
  se: { x: 1, y: 1 },
  sw: { x: -1, y: 1 },
  ne: { x: 1, y: -1 },
  nw: { x: -1, y: -1 },
}

interface DragState {
  key: ElementKey
  /** Pointer position, in dots, minus the element's position at drag start —
   * kept constant through the drag so the element moves with the pointer
   * instead of snapping its top-left corner under it. */
  offsetX: number
  offsetY: number
}

interface ResizeState {
  key: ResizableKey
  corner: Corner
  /** Pointer position, in dots, at drag start. */
  startDotsX: number
  startDotsY: number
  /** Font index (0–7) at drag start — only meaningful for text elements. */
  startFont: number
  /** Barcode bar height and module width, in dots, at drag start — only meaningful for the barcode. */
  startBarcodeHeight: number
  startBarcodeModuleWidth: number
  /** Logo box width and height, in dots, at drag start — only meaningful for the logo. */
  startLogoWidth: number
  startLogoHeight: number
}

interface ResizeLiveValue {
  key: ResizableKey
  font: number
  barcodeHeight: number
  barcodeModuleWidth: number
  logoWidth: number
  logoHeight: number
}

interface Footprint {
  width: number
  height: number
}

function LabelCanvas({
  template,
  logoDataUrl,
  isPolono,
  onMove,
  onFontResize,
  onFontSizeResize,
  onBarcodeResize,
  onLogoResize,
}: {
  template: LabelTemplate
  logoDataUrl?: string
  /** Whether the name/variation/SKU text resize continuously in real dots
   * (Polono) or step through the Zebra's 8 fixed CPCL font sizes — see
   * `textSizeDotsFor` in `labelTemplate.ts`. */
  isPolono: boolean
  onMove: (key: ElementKey, position: ElementPosition) => void
  /** Zebra only — steps through the CPCL font index (0–7). */
  onFontResize: (key: TextElementKey, font: number) => void
  /** Polono only — sets the real, continuous size in dots. */
  onFontSizeResize: (key: TextElementKey, sizeDots: number) => void
  onBarcodeResize: (next: { heightDots: number; moduleWidth: number }) => void
  onLogoResize: (next: { widthDots: number; heightDots: number }) => void
}) {
  const t = template
  const svgRef = useRef<SVGSVGElement>(null)
  const [drag, setDrag] = useState<DragState | null>(null)
  // The dragged element's position while the drag is in flight — kept out of
  // the saved template (and out of localStorage) until pointerup, so a drag
  // doesn't write to storage on every pixel of movement.
  const [livePosition, setLivePosition] = useState<{ key: ElementKey; position: ElementPosition } | null>(null)

  const [resize, setResize] = useState<ResizeState | null>(null)
  // Same idea as livePosition, but for the value(s) a resize handle is changing.
  const [liveResizeValue, setLiveResizeValue] = useState<ResizeLiveValue | null>(null)

  const scale = Math.min(1, PREVIEW_MAX_WIDTH / t.widthDots)
  const px = (dots: number) => dots * scale

  const positionOf = (key: ElementKey): ElementPosition =>
    livePosition && livePosition.key === key ? livePosition.position : t[key]

  const fontOf = (key: TextElementKey): number =>
    liveResizeValue && liveResizeValue.key === key && !isPolono ? liveResizeValue.font : t[FONT_FIELD[key]]

  // The real, rendered text height in dots — the Zebra's stepped
  // `textHeightDots(fontIndex)` or the Polono's continuous override, plus
  // whatever's live mid-resize. `liveResizeValue.font` holds a font *index*
  // while dragging a Zebra resize handle, or a size *in dots* directly while
  // dragging a Polono one — `sizeOf` is the one place that distinction is
  // resolved, so nothing else needs to know which mode produced it.
  const sizeOf = (key: TextElementKey): number => {
    if (liveResizeValue && liveResizeValue.key === key) {
      return isPolono ? liveResizeValue.font : textHeightDots(liveResizeValue.font)
    }
    return textSizeDotsFor(t, key, isPolono)
  }

  const familyOf = (key: TextElementKey): string => textFamilyFor(t, key, isPolono)

  const barcodeHeightOf = (): number =>
    liveResizeValue && liveResizeValue.key === 'barcode' ? liveResizeValue.barcodeHeight : t.barcodeHeight

  const barcodeModuleWidthOf = (): number =>
    liveResizeValue && liveResizeValue.key === 'barcode' ? liveResizeValue.barcodeModuleWidth : t.barcodeModuleWidth

  const logoWidthOf = (): number =>
    liveResizeValue && liveResizeValue.key === 'logo' ? liveResizeValue.logoWidth : t.logoWidthDots

  const logoHeightOf = (): number =>
    liveResizeValue && liveResizeValue.key === 'logo' ? liveResizeValue.logoHeight : t.logoHeightDots

  // Every element's on-screen size, right now (including live drag/resize
  // values) — the single source of truth for both what's drawn and how far
  // a drag or nudge is allowed to go, so an element can never be pushed
  // somewhere its own bulk would hang off the label.
  const nameSize = sizeOf('name')
  const variationSize = sizeOf('variation')
  const skuSize = sizeOf('sku')
  const nameFamily = familyOf('name')
  const variationFamily = familyOf('variation')
  const skuFamily = familyOf('sku')
  const barcodeHeight = barcodeHeightOf()
  const barcodeModuleWidth = barcodeModuleWidthOf()
  const logoWidth = logoWidthOf()
  const logoHeight = logoHeightOf()

  const nameWidth = approxTextWidthDots(SAMPLE_PRODUCT.name, nameSize)
  const variationWidth = approxTextWidthDots(`Variation: ${SAMPLE_PRODUCT.variation}`, variationSize)
  const skuWidth = approxTextWidthDots(SAMPLE_PRODUCT.sku, skuSize)

  // What actually prints — see `truncateToFitDots` in `labelTemplate.ts`.
  // The dashed hit-box below still uses the full, untruncated width above
  // (a slightly more generous drag boundary than strictly necessary is
  // harmless; what matters is that the *text drawn inside it* matches the
  // real, possibly-shortened print output).
  const nameDisplay = truncateToFitDots(SAMPLE_PRODUCT.name, t.widthDots - positionOf('name').x, nameSize)
  const variationDisplay = truncateToFitDots(
    `Variation: ${SAMPLE_PRODUCT.variation}`,
    t.widthDots - positionOf('variation').x,
    variationSize,
  )
  const skuDisplay = truncateToFitDots(SAMPLE_PRODUCT.sku, t.widthDots - positionOf('sku').x, skuSize)
  const barcodeWidth = estimateBarcodeWidthDots(barcodeModuleWidth)

  const footprintOf = (key: ElementKey): Footprint => {
    switch (key) {
      case 'logo':
        return { width: logoWidth, height: logoHeight }
      case 'name':
        return { width: nameWidth, height: nameSize }
      case 'variation':
        return { width: variationWidth, height: variationSize }
      case 'barcode':
        return { width: barcodeWidth, height: barcodeHeight }
      case 'sku':
        return { width: skuWidth, height: skuSize }
    }
  }

  const clientToDots = (clientX: number, clientY: number): ElementPosition => {
    const rect = svgRef.current!.getBoundingClientRect()
    return {
      x: ((clientX - rect.left) / rect.width) * t.widthDots,
      y: ((clientY - rect.top) / rect.height) * t.heightDots,
    }
  }

  /** Clamps a position so the element's whole footprint — not just its
   * origin corner — stays on the label. Dragging (or nudging) an element
   * mostly off the label used to be possible because only the origin point
   * was kept in bounds; the browser's SVG preview clips the overhang so it
   * looked roughly fine on screen, but the real printer doesn't clip its
   * TEXT/BARCODE/EG commands, so the overrun corrupted the physical print. */
  const clampToLabel = (position: ElementPosition, footprint: Footprint): ElementPosition => ({
    x: Math.round(clampNum(position.x, 0, Math.max(0, t.widthDots - footprint.width))),
    y: Math.round(clampNum(position.y, 0, Math.max(0, t.heightDots - footprint.height))),
  })

  const startDrag = (key: ElementKey) => (event: React.PointerEvent) => {
    event.preventDefault()
    event.currentTarget.setPointerCapture(event.pointerId)
    const pointerDots = clientToDots(event.clientX, event.clientY)
    const current = t[key]
    setDrag({ key, offsetX: pointerDots.x - current.x, offsetY: pointerDots.y - current.y })
    setLivePosition({ key, position: current })
  }

  const startResize = (key: ResizableKey, corner: Corner) => (event: React.PointerEvent) => {
    event.preventDefault()
    event.stopPropagation() // don't also start a move-drag on the parent box
    event.currentTarget.setPointerCapture(event.pointerId)
    const pointerDots = clientToDots(event.clientX, event.clientY)
    // Always captured as a dot height for a text element (via `sizeOf`,
    // which already resolves the Zebra-index-vs-Polono-continuous split) —
    // see the matching branch in `onPointerMove` below.
    const startFont = key === 'barcode' || key === 'logo' ? 0 : sizeOf(key as TextElementKey)
    setResize({
      key,
      corner,
      startDotsX: pointerDots.x,
      startDotsY: pointerDots.y,
      startFont,
      startBarcodeHeight: t.barcodeHeight,
      startBarcodeModuleWidth: t.barcodeModuleWidth,
      startLogoWidth: t.logoWidthDots,
      startLogoHeight: t.logoHeightDots,
    })
    setLiveResizeValue({
      key,
      font: startFont,
      barcodeHeight: t.barcodeHeight,
      barcodeModuleWidth: t.barcodeModuleWidth,
      logoWidth: t.logoWidthDots,
      logoHeight: t.logoHeightDots,
    })
  }

  const onPointerMove = (event: React.PointerEvent) => {
    if (drag) {
      const pointerDots = clientToDots(event.clientX, event.clientY)
      const next = clampToLabel(
        { x: pointerDots.x - drag.offsetX, y: pointerDots.y - drag.offsetY },
        footprintOf(drag.key),
      )
      setLivePosition({ key: drag.key, position: next })
      return
    }
    if (resize) {
      const pointerDots = clientToDots(event.clientX, event.clientY)
      const sign = CORNER_SIGN[resize.corner]
      const deltaX = (pointerDots.x - resize.startDotsX) * sign.x
      const deltaY = (pointerDots.y - resize.startDotsY) * sign.y
      if (resize.key === 'barcode') {
        const nextHeight = Math.round(clampNum(resize.startBarcodeHeight + deltaY, 10, 1000))
        // 20 dots of drag per module-width step keeps the drag feeling
        // proportional — the module width only ranges 1–10 dots, a much
        // smaller range than the pixel distance a hand naturally drags.
        const nextModuleWidth = Math.round(clampNum(resize.startBarcodeModuleWidth + deltaX / 20, 1, 10))
        setLiveResizeValue({
          key: 'barcode',
          font: 0,
          barcodeHeight: nextHeight,
          barcodeModuleWidth: nextModuleWidth,
          logoWidth: 0,
          logoHeight: 0,
        })
      } else if (resize.key === 'logo') {
        // Unlike the barcode's tiny 1–10 module-width range, the logo box
        // spans up to MAX_LOGO_DOTS, so a direct 1 drag-dot : 1 box-dot
        // mapping (no slowing divisor) feels right here.
        const nextWidth = Math.round(clampNum(resize.startLogoWidth + deltaX, MIN_LOGO_DOTS, MAX_LOGO_DOTS))
        const nextHeight = Math.round(clampNum(resize.startLogoHeight + deltaY, MIN_LOGO_DOTS, MAX_LOGO_DOTS))
        setLiveResizeValue({
          key: 'logo',
          font: 0,
          barcodeHeight: 0,
          barcodeModuleWidth: 0,
          logoWidth: nextWidth,
          logoHeight: nextHeight,
        })
      } else if (isPolono) {
        // `resize.startFont` already holds the starting size in dots (see
        // `startResize` above) — continuous, no 6-dot-per-step rounding.
        const nextSize = Math.round(clampNum(resize.startFont + deltaY, MIN_CUSTOM_FONT_DOTS, MAX_CUSTOM_FONT_DOTS))
        setLiveResizeValue({ key: resize.key, font: nextSize, barcodeHeight: 0, barcodeModuleWidth: 0, logoWidth: 0, logoHeight: 0 })
      } else {
        // `resize.startFont` is a dot height here too (from `sizeOf`) —
        // convert the drag delta the same way the old index-stepped logic
        // did, just without re-deriving the starting height from an index.
        const nextFont = Math.round(clampNum((resize.startFont + deltaY - 14) / 6, MIN_FONT, MAX_FONT))
        setLiveResizeValue({ key: resize.key, font: nextFont, barcodeHeight: 0, barcodeModuleWidth: 0, logoWidth: 0, logoHeight: 0 })
      }
    }
  }

  const endInteraction = () => {
    if (drag && livePosition) onMove(drag.key, livePosition.position)
    if (resize && liveResizeValue) {
      if (resize.key === 'barcode') {
        onBarcodeResize({ heightDots: liveResizeValue.barcodeHeight, moduleWidth: liveResizeValue.barcodeModuleWidth })
      } else if (resize.key === 'logo') {
        onLogoResize({ widthDots: liveResizeValue.logoWidth, heightDots: liveResizeValue.logoHeight })
      } else if (isPolono) {
        onFontSizeResize(resize.key, liveResizeValue.font)
      } else {
        onFontResize(resize.key, liveResizeValue.font)
      }
    }
    setDrag(null)
    setLivePosition(null)
    setResize(null)
    setLiveResizeValue(null)
  }

  const nudge = (key: ElementKey, dx: number, dy: number) => {
    const current = positionOf(key)
    onMove(key, clampToLabel({ x: current.x + dx, y: current.y + dy }, footprintOf(key)))
  }

  const onKeyDownFor = (key: ElementKey) => (event: React.KeyboardEvent) => {
    const step = event.shiftKey ? 10 : 1
    if (event.key === 'ArrowLeft') { event.preventDefault(); nudge(key, -step, 0) }
    else if (event.key === 'ArrowRight') { event.preventDefault(); nudge(key, step, 0) }
    else if (event.key === 'ArrowUp') { event.preventDefault(); nudge(key, 0, -step) }
    else if (event.key === 'ArrowDown') { event.preventDefault(); nudge(key, 0, step) }
  }

  const onResizeKeyDownFor = (key: ResizableKey) => (event: React.KeyboardEvent) => {
    const step = event.shiftKey ? 10 : 1
    if (key === 'barcode') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault()
        event.stopPropagation()
        const grow = event.key === 'ArrowUp'
        onBarcodeResize({
          heightDots: Math.round(clampNum(barcodeHeightOf() + (grow ? step : -step), 10, 1000)),
          moduleWidth: barcodeModuleWidthOf(),
        })
      } else if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault()
        event.stopPropagation()
        const grow = event.key === 'ArrowRight'
        onBarcodeResize({
          heightDots: barcodeHeightOf(),
          moduleWidth: Math.round(clampNum(barcodeModuleWidthOf() + (grow ? 1 : -1), 1, 10)),
        })
      }
      return
    }
    if (key === 'logo') {
      if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
        event.preventDefault()
        event.stopPropagation()
        const grow = event.key === 'ArrowUp'
        onLogoResize({
          widthDots: logoWidthOf(),
          heightDots: Math.round(clampNum(logoHeightOf() + (grow ? step : -step), MIN_LOGO_DOTS, MAX_LOGO_DOTS)),
        })
      } else if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
        event.preventDefault()
        event.stopPropagation()
        const grow = event.key === 'ArrowRight'
        onLogoResize({
          widthDots: Math.round(clampNum(logoWidthOf() + (grow ? step : -step), MIN_LOGO_DOTS, MAX_LOGO_DOTS)),
          heightDots: logoHeightOf(),
        })
      }
      return
    }
    if (event.key !== 'ArrowUp' && event.key !== 'ArrowDown') return
    event.preventDefault()
    event.stopPropagation()
    const grow = event.key === 'ArrowUp'
    const textKey = key as TextElementKey
    if (isPolono) {
      const current = sizeOf(textKey)
      onFontSizeResize(textKey, Math.round(clampNum(current + (grow ? step : -step), MIN_CUSTOM_FONT_DOTS, MAX_CUSTOM_FONT_DOTS)))
    } else {
      const current = fontOf(textKey)
      onFontResize(textKey, clampNum(current + (grow ? 1 : -1), MIN_FONT, MAX_FONT))
    }
  }

  const logoPos = positionOf('logo')
  const namePos = positionOf('name')
  const variationPos = positionOf('variation')
  const barcodePos = positionOf('barcode')
  const skuPos = positionOf('sku')

  // An unticked element (see LabelElementVisibility) isn't drawn at all, so
  // it can't be off-label either — no point warning about something that
  // isn't printing.
  //
  // Name/variation/SKU text no longer get a *horizontal* off-label check —
  // `truncateToFitDots` (see `labelTemplate.ts`) now shortens each of them
  // at print time (and in the preview below) to whatever room they have
  // left before the label's right edge, so a long product name can't
  // actually run off the label horizontally any more; it just prints
  // shorter, with a "…" showing something was cut. Vertical overflow still
  // gets flagged — dropping a text element too close to the bottom isn't
  // something shortening the text can fix, only dragging it up can. The
  // logo and barcode keep both checks: neither can be auto-shrunk the way
  // text can (a barcode's encoded value must stay intact — see
  // `truncateToFitDots`'s doc comment — and a logo would just distort).
  const offLabel: string[] = []
  if (t.include.logo && logoDataUrl && (logoPos.x + logoWidth > t.widthDots || logoPos.y + logoHeight > t.heightDots))
    offLabel.push('Logo')
  if (t.include.name && namePos.y + nameSize > t.heightDots) offLabel.push('Name')
  if (t.include.variation && variationPos.y + variationSize > t.heightDots) offLabel.push('Variation')
  if (t.include.barcode && (barcodePos.x + barcodeWidth > t.widthDots || barcodePos.y + barcodeHeight > t.heightDots))
    offLabel.push('Barcode')
  if (t.include.sku && skuPos.y + skuSize > t.heightDots) offLabel.push('SKU text')

  // The decorative/hit-area box drawn around every element is padded out
  // slightly beyond its real footprint so it's easier to grab and to read
  // its label tag — purely a visual and click-target aid. It's deliberately
  // small (not the old 4/8) so it doesn't eat into how close two elements
  // (e.g. a circular logo and neighbouring text) can visually sit to each
  // other or the label edge — this padding has never affected the real
  // clamp/print bounds, which are governed by each element's actual
  // footprint in `clampToLabel`, not by this box.
  const FRAME_PAD = 2

  const handlePosition = (corner: Corner, width: number, height: number) => ({
    cx: corner === 'ne' || corner === 'se' ? width + FRAME_PAD : -FRAME_PAD,
    cy: corner === 'sw' || corner === 'se' ? height + FRAME_PAD : -FRAME_PAD,
  })

  /** A draggable bounding box with a small tag naming the element, a
   * transparent hit-area covering the whole box (bigger and easier to grab
   * than the thin text/bars it contains), and — for resizable elements — a
   * handle circle at each of the four corners, so there's always one
   * reachable even if the element has been dragged off the label. */
  const draggable = (
    key: ElementKey,
    x: number,
    y: number,
    width: number,
    height: number,
    content: React.ReactNode,
    resizeKey?: ResizableKey,
  ) => (
    <g
      key={key}
      transform={`translate(${x}, ${y})`}
      tabIndex={0}
      role="button"
      aria-label={`${ELEMENT_LABEL[key]} — drag to move, or focus and use arrow keys`}
      onPointerDown={startDrag(key)}
      onKeyDown={onKeyDownFor(key)}
      style={{ cursor: 'grab', outline: 'none' }}
      className={drag?.key === key ? 'label-canvas-dragging' : undefined}
    >
      <rect
        x={-FRAME_PAD}
        y={-FRAME_PAD}
        width={width + FRAME_PAD * 2}
        height={height + FRAME_PAD * 2}
        fill="rgba(57,211,187,0.06)"
        stroke={drag?.key === key ? '#39d3bb' : 'rgba(57,211,187,0.55)'}
        strokeDasharray={drag?.key === key ? undefined : '5 4'}
        strokeWidth={drag?.key === key ? 2 : 1}
        rx={4}
      />
      <text x={0} y={-7} fontSize={9} fontFamily="ui-sans-serif, system-ui" fill="#39d3bb" style={{ pointerEvents: 'none' }}>
        {ELEMENT_LABEL[key]}
      </text>
      {content}
      {resizeKey &&
        CORNERS.map((corner) => {
          const { cx, cy } = handlePosition(corner, width, height)
          const isActive = resize?.key === resizeKey && resize.corner === corner
          const cursor = corner === 'ne' || corner === 'sw' ? 'nesw-resize' : 'nwse-resize'
          const valueText =
            resizeKey === 'barcode'
              ? `height ${barcodeHeight} dots, width ${barcodeModuleWidth} dots per bar`
              : resizeKey === 'logo'
                ? `width ${logoWidth} dots, height ${logoHeight} dots`
                : isPolono
                  ? `size ${sizeOf(resizeKey as TextElementKey)} dots`
                  : `font ${fontOf(resizeKey as TextElementKey)}`
          const twoAxis = resizeKey === 'barcode' || resizeKey === 'logo'
          return (
            <circle
              key={corner}
              cx={cx}
              cy={cy}
              r={6}
              fill="#39d3bb"
              stroke="#07111f"
              strokeWidth={1.5}
              tabIndex={0}
              role="slider"
              aria-label={`Resize ${ELEMENT_LABEL[key]} (${corner} handle) — drag${twoAxis ? ', or focus and use the arrow keys for height and width' : ', or focus and press the up/down arrow keys'}`}
              aria-valuetext={valueText}
              onPointerDown={startResize(resizeKey, corner)}
              onKeyDown={onResizeKeyDownFor(resizeKey)}
              className={isActive ? 'label-canvas-dragging' : undefined}
              style={{ cursor }}
            />
          )
        })}
    </g>
  )

  return (
    <div className="label-preview-wrap">
      <svg
        ref={svgRef}
        className="label-preview-svg label-canvas-svg"
        width={px(t.widthDots)}
        height={px(t.heightDots)}
        viewBox={`0 0 ${t.widthDots} ${t.heightDots}`}
        role="group"
        aria-label="Label layout — drag the logo, name, variation, barcode and SKU text to place them"
        onPointerMove={onPointerMove}
        onPointerUp={endInteraction}
        onPointerCancel={endInteraction}
      >
        <rect x={0} y={0} width={t.widthDots} height={t.heightDots} fill="#fff" stroke="#243b55" />

        {t.include.logo &&
          (logoDataUrl
            ? draggable(
                'logo',
                logoPos.x,
                logoPos.y,
                logoWidth,
                logoHeight,
                <image href={logoDataUrl} width={logoWidth} height={logoHeight} preserveAspectRatio="xMidYMid meet" style={{ pointerEvents: 'none' }} />,
                'logo',
              )
            : draggable(
                'logo',
                logoPos.x,
                logoPos.y,
                logoWidth,
                logoHeight,
                <text x={logoWidth / 2} y={logoHeight / 2 + 4} textAnchor="middle" fontSize={11} fill="#94a3b8" style={{ pointerEvents: 'none' }}>
                  (no logo uploaded)
                </text>,
                'logo',
              ))}

        {t.include.name &&
          draggable(
            'name',
            namePos.x,
            namePos.y,
            nameWidth,
            nameSize,
            <text x={0} y={nameSize} fontSize={nameSize} fontFamily={nameFamily} fill="#0a0a0a" style={{ pointerEvents: 'none' }}>
              {nameDisplay}
            </text>,
            'name',
          )}

        {t.include.variation &&
          draggable(
            'variation',
            variationPos.x,
            variationPos.y,
            variationWidth,
            variationSize,
            <text x={0} y={variationSize} fontSize={variationSize} fontFamily={variationFamily} fill="#333" style={{ pointerEvents: 'none' }}>
              {variationDisplay}
            </text>,
            'variation',
          )}

        {t.include.barcode &&
          draggable(
            'barcode',
            barcodePos.x,
            barcodePos.y,
            barcodeWidth,
            barcodeHeight,
            <g style={{ pointerEvents: 'none' }}>
              {/* Fake barcode bars — a layout guide, not a real Code 128 encode —
                  spaced and sized to track the module width so the preview shows
                  roughly how much wider the barcode gets. */}
              {Array.from({ length: 26 }, (_, i) => {
                const barWidth = (i % 3 === 0 ? 3 : 1) * barcodeModuleWidth
                return <rect key={i} x={i * 4 * barcodeModuleWidth} y={0} width={barWidth} height={barcodeHeight} fill="#0a0a0a" />
              })}
            </g>,
            'barcode',
          )}

        {t.include.sku &&
          draggable(
            'sku',
            skuPos.x,
            skuPos.y,
            skuWidth,
            skuSize,
            <text x={0} y={skuSize} fontSize={skuSize} fontFamily={skuFamily} fill="#333" style={{ pointerEvents: 'none' }}>
              {skuDisplay}
            </text>,
            'sku',
          )}
      </svg>

      {offLabel.length > 0 && (
        <p className="alert" role="alert">
          {offLabel.join(', ')} {offLabel.length === 1 ? 'runs' : 'run'} past the edge of the label — drag it back to bring it fully on.
        </p>
      )}
    </div>
  )
}

/** Save the current layout under a name, and switch back to any saved one —
 * "Shipping label", "RV", "Product label", whatever's printed differently.
 * Only one layout is ever live/editing at once (above, in `LabelCanvas`);
 * saving copies it into the list under a name, loading copies it back. */
function LabelPresetsPanel({ settings, template }: { settings: SettingsApi; template: LabelTemplate }) {
  const idPrefix = useId()
  const [name, setName] = useState('')

  const save = (event: FormEvent) => {
    event.preventDefault()
    const trimmed = name.trim()
    if (!trimmed) return
    settings.saveLabelPreset(trimmed, template)
    setName('')
  }

  return (
    <section className="panel">
      <h2>Label presets</h2>
      <p className="muted">
        Save the layout above under a name, then load any saved one back whenever you need to
        switch what you're printing for — a shipping label one day, a different product label
        the next. Saving doesn't change what's currently live; only loading does.
      </p>

      {settings.labelPresets.length === 0 ? (
        <p className="empty">No presets saved yet — set up a layout above, then save it below.</p>
      ) : (
        <ul className="plain-list channel-list">
          {settings.labelPresets.map((preset) => (
            <li key={preset.id} className="channel-row">
              <input
                className="channel-rename-input"
                defaultValue={preset.name}
                autoComplete="off"
                aria-label={`Rename ${preset.name}`}
                onKeyDown={commitOnEnter}
                onBlur={(event) => {
                  const next = event.target.value.trim()
                  if (next && next !== preset.name) settings.renameLabelPreset(preset.id, next)
                  else event.target.value = preset.name
                }}
              />
              <div className="toolbar-actions">
                <button type="button" className="button button-ghost" onClick={() => settings.applyLabelPreset(preset.id)}>
                  Load
                </button>
                <button
                  type="button"
                  className="button button-ghost"
                  aria-label={`Delete ${preset.name}`}
                  onClick={() => settings.deleteLabelPreset(preset.id)}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}

      <form className="toolbar" onSubmit={save}>
        <div className="field field-grow">
          <label htmlFor={`${idPrefix}-preset-name`}>Save current layout as</label>
          <input
            id={`${idPrefix}-preset-name`}
            value={name}
            autoComplete="off"
            placeholder="e.g. Shipping label"
            onChange={(event) => setName(event.target.value)}
          />
          <p className="hint">Saving over an existing name replaces that preset.</p>
        </div>
        <div className="toolbar-actions">
          <button type="submit" className="button button-primary">
            Save preset
          </button>
        </div>
      </form>
    </section>
  )
}

/**
 * A collapsed-by-default disclosure panel for one group of settings — the
 * screen used to show every field at once (positions, sizes, fonts,
 * darkness/speed, orientation, all flat on the page simultaneously), which
 * read as "too many options" even to set up once, let alone come back to
 * for a single tweak. Collapsing everything except the printer choice, the
 * "what's on this label" toggles and the drag-to-position preview itself
 * means the screen opens simple, and a section only gets as complicated as
 * the thing you actually came here to change.
 */
function Section({
  title,
  defaultOpen = false,
  children,
}: {
  title: string
  defaultOpen?: boolean
  children: React.ReactNode
}) {
  const [open, setOpen] = useState(defaultOpen)
  const bodyId = useId()
  return (
    <div className="field" style={{ borderTop: '1px solid rgba(148,163,184,0.18)', paddingTop: 10 }}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        aria-controls={bodyId}
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          width: '100%',
          background: 'none',
          border: 'none',
          padding: '4px 0',
          margin: 0,
          cursor: 'pointer',
          font: 'inherit',
          color: 'inherit',
          textAlign: 'left',
        }}
      >
        <span
          aria-hidden="true"
          style={{ display: 'inline-block', transform: open ? 'rotate(90deg)' : 'rotate(0deg)', transition: 'transform 0.15s', fontSize: 12 }}
        >
          ▶
        </span>
        <span className="label-like" style={{ margin: 0 }}>
          {title}
        </span>
      </button>
      {open && (
        <div id={bodyId} style={{ paddingTop: 8, display: 'flex', flexDirection: 'column', gap: 10 }}>
          {children}
        </div>
      )}
    </div>
  )
}

export function LabelTemplateEditor({ settings }: LabelTemplateEditorProps) {
  const idPrefix = useId()
  const printerKind = settings.printerKind
  const isPolono = printerKind === 'polono'
  const template = isPolono
    ? settings.polonoLabelTemplate ?? DEFAULT_POLONO_LABEL_TEMPLATE
    : settings.labelTemplate ?? DEFAULT_LABEL_TEMPLATE
  const [printStatus, setPrintStatus] = useState<string | null>(null)
  const [printing, setPrinting] = useState(false)
  // Real-world units by default — dots is still available in the picker for
  // anyone who wants pixel-exact control, but millimetres/inches is what
  // reads as an actual physical size without doing DPI math in your head.
  const [unit, setUnit] = useState<Unit>('mm')

  const update = (patch: Partial<LabelTemplate>) => {
    const merged = { ...template, ...patch }
    if (isPolono) {
      settings.setPolonoLabelTemplate(merged)
    } else {
      settings.setLabelTemplate(sanitiseLabelTemplate(merged))
    }
  }

  const numberField = (
    key: keyof typeof FIELD_LIMITS,
    label: string,
    options?: { hint?: string; dimension?: boolean },
  ) => {
    const isDimension = options?.dimension ?? true
    const limits = FIELD_LIMITS[key]
    const fieldId = `${idPrefix}-${key}`
    const rawDots = template[key]

    // In dots, the field's own custom hint (if any) is shown — usually context like
    // "3.00 in at 200 dpi". In inches/mm, that's redundant with the field itself, so
    // show the underlying dots value instead — useful since CPCL commands are dots.
    const hint = isDimension && unit !== 'dots' ? `${rawDots} dots` : options?.hint

    return (
      <DimensionField
        key={key}
        id={fieldId}
        label={label}
        dotsValue={rawDots}
        dpi={template.dpi}
        unit={unit}
        min={limits.min}
        max={limits.max}
        isDimension={isDimension}
        hint={hint}
        onCommit={(dots) => update({ [key]: dots } as Partial<LabelTemplate>)}
      />
    )
  }

  /** X or Y position of one of the five elements, as a real dimension field
   * (mm/in/dots, same as every other size on this screen) — lets a position
   * be typed precisely instead of only ever set by eye while dragging on
   * the small canvas above. The canvas and these fields both write to (and
   * read from) the same `template[key]`, so a drag updates the field and
   * typing a value moves the element on the canvas. */
  const positionField = (key: ElementKey, axis: 'x' | 'y', label: string) => {
    const fieldId = `${idPrefix}-${key}-${axis}`
    const rawDots = template[key][axis]
    return (
      <DimensionField
        key={fieldId}
        id={fieldId}
        label={label}
        dotsValue={rawDots}
        dpi={template.dpi}
        unit={unit}
        min={0}
        max={axis === 'x' ? template.widthDots : template.heightDots}
        isDimension
        hint={unit !== 'dots' ? `${Math.round(rawDots)} dots` : undefined}
        onCommit={(dots) => update({ [key]: { ...template[key], [axis]: dots } } as Partial<LabelTemplate>)}
      />
    )
  }

  /**
   * Which text element the "Text style" controls below currently edit —
   * `'all'` (the default) keeps name/variation/SKU matching, the way a word
   * processor's font/size boxes apply to the whole document until you
   * select something specific. Picking one element here is the equivalent
   * of that selection: the same Font/Size fields switch to showing (and
   * only changing) that one element, leaving the other two exactly as they
   * were. Resets to `'all'` on every fresh mount (e.g. navigating away and
   * back) rather than being saved — it's a UI focus, not label data.
   */
  const [textTarget, setTextTarget] = useState<TextElementKey | 'all'>('all')
  const textTargets: TextElementKey[] = textTarget === 'all' ? ['name', 'variation', 'sku'] : [textTarget]
  // What the Font/Size fields actually display while "All text" is selected
  // — there's no single value to show once the three can differ (e.g. after
  // switching one of them individually), so the name's own value stands in
  // as the representative. Changing the field re-syncs all three to
  // whatever's typed, bringing them back in line.
  const textRepresentative: TextElementKey = textTarget === 'all' ? 'name' : textTarget

  const TEXT_TARGET_OPTIONS: { value: TextElementKey | 'all'; label: string }[] = [
    { value: 'all', label: 'All text' },
    { value: 'name', label: 'Name' },
    { value: 'variation', label: 'Variation' },
    { value: 'sku', label: 'SKU' },
  ]

  const textTargetTabs = (
    <div className="field">
      <span className="label-like">Editing</span>
      <div className="checkbox-field-row" role="radiogroup" aria-label="Which text the font and size below change">
        {TEXT_TARGET_OPTIONS.map(({ value, label }) => (
          <label key={value} className="checkbox-field">
            <input
              type="radio"
              name={`${idPrefix}-text-target`}
              checked={textTarget === value}
              onChange={() => setTextTarget(value)}
            />
            {label}
          </label>
        ))}
      </div>
      <span className="hint">
        {textTarget === 'all'
          ? "Font and size below apply to the name, variation and SKU text together, so they stay matching."
          : `Font and size below apply only to the ${TEXT_TARGET_OPTIONS.find((o) => o.value === textTarget)?.label} text — the others are untouched.`}
      </span>
    </div>
  )

  /** Polono: one continuous size field that writes to every element
   * `textTarget` currently covers — `'all'` writes the same size to
   * name/variation/skuFontSizeDots at once. */
  const unifiedFontSizeField = () => {
    const fieldId = `${idPrefix}-text-size`
    const rawDots = textSizeDotsFor(template, textRepresentative, true)
    return (
      <DimensionField
        key={fieldId}
        id={fieldId}
        label="Size"
        dotsValue={rawDots}
        dpi={template.dpi}
        unit={unit}
        min={MIN_CUSTOM_FONT_DOTS}
        max={MAX_CUSTOM_FONT_DOTS}
        isDimension
        hint={unit !== 'dots' ? `${Math.round(rawDots)} dots` : undefined}
        onCommit={(dots) => {
          const patch: Partial<LabelTemplate> = {}
          for (const key of textTargets) patch[FONT_SIZE_FIELD[key]] = dots
          update(patch)
        }}
      />
    )
  }

  /** Polono: one font-family picker with a live preview, writing to every
   * element `textTarget` currently covers — same "all unless selected"
   * behaviour as the size field above. */
  const unifiedFontFamilyField = () => {
    const fieldId = `${idPrefix}-text-family`
    const family = textFamilyFor(template, textRepresentative, true)
    const sizeDots = textSizeDotsFor(template, textRepresentative, true)
    const previewPx = Math.min(Math.max(sizeDots * 0.55, 12), 40)
    const previewText =
      textRepresentative === 'variation'
        ? `Variation: ${SAMPLE_PRODUCT.variation}`
        : textRepresentative === 'sku'
          ? SAMPLE_PRODUCT.sku
          : SAMPLE_PRODUCT.name
    return (
      <div className="field" key={fieldId}>
        <label htmlFor={fieldId}>Font</label>
        <select
          id={fieldId}
          value={family}
          onChange={(event) => {
            const patch: Partial<LabelTemplate> = {}
            for (const key of textTargets) patch[FONT_FAMILY_FIELD[key]] = event.target.value
            update(patch)
          }}
        >
          {POLONO_FONT_CHOICES.map((choice) => (
            <option key={choice.family} value={choice.family}>
              {choice.label}
            </option>
          ))}
        </select>
        <div
          style={{
            fontFamily: family,
            fontSize: `${previewPx}px`,
            padding: '6px 10px',
            marginTop: 4,
            border: '1px solid rgba(57,211,187,0.35)',
            borderRadius: 6,
            background: 'rgba(57,211,187,0.06)',
            color: '#0a0a0a',
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
          }}
        >
          {previewText}
        </div>
      </div>
    )
  }

  /** Zebra: one CPCL font-index picker (still just the printer's 8 fixed
   * steps — see `fontField`'s doc comment on `LabelTemplate.nameFont` for
   * why there's no continuous option here), writing to every element
   * `textTarget` currently covers. */
  const unifiedFontIndexField = () => {
    const fieldId = `${idPrefix}-text-font`
    const value = template[FONT_FIELD[textRepresentative]]
    return (
      <div className="field" key={fieldId}>
        <label htmlFor={fieldId}>Size</label>
        <select
          id={fieldId}
          value={value}
          onChange={(event) => {
            const font = Number(event.target.value)
            const patch: Partial<LabelTemplate> = {}
            for (const key of textTargets) patch[FONT_FIELD[key]] = font
            update(patch)
          }}
        >
          {Array.from({ length: MAX_FONT - MIN_FONT + 1 }, (_, i) => MIN_FONT + i).map((font) => (
            <option key={font} value={font}>
              Font {font}
            </option>
          ))}
        </select>
      </div>
    )
  }

  const ELEMENT_TOGGLES: { key: keyof LabelTemplate['include']; label: string }[] = [
    { key: 'name', label: 'Name' },
    { key: 'variation', label: 'Variation' },
    { key: 'barcode', label: 'Barcode' },
    { key: 'sku', label: 'SKU text' },
    { key: 'logo', label: 'Logo' },
  ]

  const visibilityField = (key: keyof LabelTemplate['include'], label: string) => {
    const fieldId = `${idPrefix}-include-${key}`
    return (
      <label key={key} className="checkbox-field" htmlFor={fieldId}>
        <input
          id={fieldId}
          type="checkbox"
          checked={template.include[key]}
          onChange={(event) => update({ include: { ...template.include, [key]: event.target.checked } })}
        />
        {label}
      </label>
    )
  }

  const printTest = async () => {
    setPrinting(true)
    setPrintStatus(isPolono ? 'Opening the print dialog…' : 'Sending test label to the printer…')
    const result = await printProductLabel(SAMPLE_PRODUCT, {
      logoDataUrl: settings.logoDataUrl,
      saleChannels: settings.saleChannels,
      printerKind,
      polonoPrintRotation: settings.polonoPrintRotation,
      labelPresets: settings.labelPresets,
      quickCodes: settings.quickCodes,
      productCategories: settings.productCategories,
      ...(isPolono ? { polonoLabelTemplate: template } : { labelTemplate: template }),
    })
    setPrintStatus(
      result.ok
        ? isPolono
          ? 'Print dialog opened — pick the Polono and confirm.'
          : 'Test label sent to the printer.'
        : `Print failed: ${result.error}`,
    )
    setPrinting(false)
  }

  return (
    <>
    <section className="panel">
      <h2>Label template</h2>
      <p className="muted">
        Drag the logo, name, variation, barcode and SKU text to where you want them on the label —
        or focus one and use the arrow keys to nudge it. Each resizable element has a handle at
        every corner, so there's always one you can grab even if it's been dragged towards the
        edge. Drag a corner to resize (up/down arrows when focused); for the barcode and the logo,
        dragging sideways — or the left/right arrow keys — resizes width instead of height. The
        logo is scaled to fit its box without stretching, so resizing it never distorts it.
        Changes are saved as you go and used the next time a label is printed.
      </p>

      <div className="field">
        <span className="label-like">Printer</span>
        <div className="checkbox-field-row" role="radiogroup" aria-label="Printer">
          {(Object.keys(PRINTER_LABELS) as PrinterKind[]).map((kind) => (
            <label key={kind} className="checkbox-field">
              <input
                type="radio"
                name={`${idPrefix}-printer-kind`}
                checked={printerKind === kind}
                onChange={() => settings.setPrinterKind(kind)}
              />
              {PRINTER_LABELS[kind]}
            </label>
          ))}
        </div>
        <span className="hint">
          {isPolono
            ? 'Prints through the normal system print dialog — pick the Polono there once its driver has it installed as a printer.'
            : 'Prints straight to the Zebra over the network, no dialog.'}
          {' '}Each printer keeps its own layout below, so switching back and forth doesn't lose either one.
        </span>
      </div>

      <div className="field">
        <span className="label-like">What's on this label</span>
        <div className="checkbox-field-row">{ELEMENT_TOGGLES.map(({ key, label }) => visibilityField(key, label))}</div>
        <span className="hint">
          Untick anything you don't want printed — its position and size are kept, so ticking it
          back on later (a bigger label, a different printer) puts it right back where it was.
        </span>
      </div>

      <LabelCanvas
        template={template}
        logoDataUrl={settings.logoDataUrl}
        isPolono={isPolono}
        onMove={(key, position) => update({ [key]: position } as Partial<LabelTemplate>)}
        onFontResize={(key, font) => update({ [FONT_FIELD[key]]: font } as Partial<LabelTemplate>)}
        onFontSizeResize={(key, size) => update({ [FONT_SIZE_FIELD[key]]: size } as Partial<LabelTemplate>)}
        onBarcodeResize={({ heightDots, moduleWidth }) => update({ barcodeHeight: heightDots, barcodeModuleWidth: moduleWidth })}
        onLogoResize={({ widthDots, heightDots }) => update({ logoWidthDots: widthDots, logoHeightDots: heightDots })}
      />

      <Section title="Text style (font &amp; size)">
        {textTargetTabs}
        <div className="field-row label-template-grid">
          {isPolono ? unifiedFontSizeField() : unifiedFontIndexField()}
          {isPolono && unifiedFontFamilyField()}
        </div>
      </Section>

      <Section title="Exact positions">
        <span className="hint">
          Dragging on the preview above still works — these are for typing an exact position
          instead. X is measured from the left edge, Y from the top.
        </span>
        {(['logo', 'name', 'variation', 'barcode', 'sku'] as ElementKey[]).map((key) => (
          <div className="field-row label-template-grid" key={key}>
            <span className="label-like" style={{ alignSelf: 'center', minWidth: 90 }}>
              {ELEMENT_LABEL[key]}
            </span>
            {positionField(key, 'x', 'X')}
            {positionField(key, 'y', 'Y')}
          </div>
        ))}
      </Section>

      <Section title="Label size &amp; barcode">
        <div className="field-row label-template-grid">
          <div className="field">
            <label htmlFor={`${idPrefix}-unit`}>Units</label>
            <select id={`${idPrefix}-unit`} value={unit} onChange={(event) => setUnit(event.target.value as Unit)}>
              {UNIT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            <span className="hint">Sizes are still stored and sent to the printer in dots.</span>
          </div>
          {numberField('dpi', 'Printer DPI', {
            dimension: false,
            hint: isPolono
              ? "The Zebra's raw print commands need this to exactly match its real 203 dpi resolution. The Polono prints through the OS print dialog instead, where this value only sets the physical size sent to the dialog (widthDots ÷ dpi) — it's tuned here, not to the Polono's 203 dpi spec, to match what this printer/driver combination actually puts on the label edge-to-edge. If your printed labels stop short of the edge again, raising this makes everything print smaller/more conservative; lowering it makes everything print bigger — change it before touching individual positions or sizes."
              : "Must match your printer's real resolution (check its spec sheet or a printed config label) — if this is wrong, every inch/mm size below prints the wrong physical size no matter how you adjust it. The Zebra QLn220 is 203 dpi.",
          })}
        </div>

        <div className="field-row label-template-grid">
          {numberField('widthDots', 'Label width', {
            hint: `${(template.widthDots / template.dpi).toFixed(2)} in at ${template.dpi} dpi`,
          })}
          {numberField('heightDots', 'Label length', {
            hint: `${(template.heightDots / template.dpi).toFixed(2)} in at ${template.dpi} dpi`,
          })}
          {numberField('barcodeHeight', 'Barcode height')}
          {numberField('barcodeModuleWidth', 'Barcode width (per bar)')}
        </div>

        <div className="field-row label-template-grid">
          {numberField('logoWidthDots', 'Logo width')}
          {numberField('logoHeightDots', 'Logo height')}
        </div>
      </Section>

      {!isPolono && (
        <Section title="Print quality">
          <div className="field-row label-template-grid">
            {numberField('darkness', 'Print darkness', {
              dimension: false,
              hint: 'Higher = darker (0–30). If the name or other text prints lighter than the barcode, raise this.',
            })}
            {numberField('printSpeedIps', 'Print speed (in/sec)', {
              dimension: false,
              hint: 'Lower = slower, giving the print head more time per label (2–12). Slower usually prints darker and cleaner.',
            })}
          </div>
        </Section>
      )}

      {isPolono && (
        <Section title="Orientation">
          <div className="checkbox-field-row" role="radiogroup" aria-label="Print orientation">
            {(
              [
                { value: 'off', label: 'Unchanged (default)' },
                { value: 'cw', label: 'Rotate 90° clockwise' },
                { value: 'ccw', label: 'Rotate 90° counter-clockwise' },
              ] as { value: PolonoPrintRotation; label: string }[]
            ).map(({ value, label }) => (
              <label key={value} className="checkbox-field">
                <input
                  type="radio"
                  name={`${idPrefix}-print-rotation`}
                  checked={settings.polonoPrintRotation === value}
                  onChange={() => settings.setPolonoPrintRotation(value)}
                />
                {label}
              </label>
            ))}
          </div>
          <span className="hint">
            Only change this if Chrome's print dialog keeps defaulting to portrait for this
            landscape label and won't stay in landscape. Test with <strong>print preview only</strong> after
            switching — do not send a real print job — until the text in the preview reads
            right-side-up and left-to-right. If neither rotation looks right in preview, leave this
            on Unchanged and use the system print dialog's own orientation control instead, the way
            you have been.
          </span>
        </Section>
      )}

      <div className="dialog-actions">
        <button
          type="button"
          className="button button-ghost"
          onClick={() => (isPolono ? settings.resetPolonoLabelTemplate() : settings.resetLabelTemplate())}
        >
          Reset to defaults
        </button>
        <button type="button" className="button button-primary" onClick={printTest} disabled={printing}>
          {printing ? 'Printing…' : 'Print test label'}
        </button>
      </div>

      {printStatus && <p className="preview">{printStatus}</p>}
    </section>

    {!isPolono && <LabelPresetsPanel settings={settings} template={template} />}
    </>
  )
}
