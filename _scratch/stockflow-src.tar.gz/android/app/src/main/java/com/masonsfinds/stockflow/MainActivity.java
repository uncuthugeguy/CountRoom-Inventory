package com.masonsfinds.stockflow;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
